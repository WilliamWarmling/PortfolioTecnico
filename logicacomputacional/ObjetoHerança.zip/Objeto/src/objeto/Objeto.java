/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objeto;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author nathan_cristiano
 */
public class Objeto {

    public static void main(String[] args) {
        //cadastraPessoa();
        cadastraAluno();
    }
    
    public static void cadastraPessoa(){
        int qnt = Integer.parseInt(JOptionPane.showInputDialog
        ("Quantas pessoas deseja cadastrar?"));
        ArrayList<Pessoa> lista = new ArrayList<>();
        for(int i = 0; i < qnt; i++){
            String nome = JOptionPane.showInputDialog
            ("Digite o nome:");
            int idade = Integer.parseInt(JOptionPane.showInputDialog
            ("Digite a idade de: "+nome));
            String cpf = JOptionPane.showInputDialog
            ("Digite o CPF de: "+nome);
            Pessoa p = new Pessoa(nome, idade, cpf);
            lista.add(p);
        }
        for(Pessoa p:lista){
            JOptionPane.showMessageDialog(null,"Nome: "+p.getNome()+
             "\nIdade: "+p.getIdade()+"\nCPF: "+p.getCpf());
        }
    }
    
    public static void cadastraAluno(){
        int qnt = Integer.parseInt(JOptionPane.showInputDialog
        ("Quantos alunos desejas cadastrar?"));
        ArrayList<Aluno> lista = new ArrayList<>();
        for(int i = 0; i < qnt; i++){
            String nome = JOptionPane.showInputDialog
            ("Digite o nome:");
            int idade = Integer.parseInt(JOptionPane.showInputDialog
            ("Digite a idade de: "+nome));
            String cpf = JOptionPane.showInputDialog
            ("Digite o CPF de: "+nome);
            int matricula = Integer.parseInt(JOptionPane.showInputDialog
            ("Digite o id da matricula: "+nome));
            Aluno p = new Aluno(matricula, nome, idade, cpf);
            lista.add(p);
        }
        for(Aluno p:lista){
            JOptionPane.showMessageDialog(null,"matricula: "+p.getMatricula()+ "\nNome: "+p.getNome()+
             "\nIdade: "+p.getIdade()+"\nCPF: "+p.getCpf());
                    
                    

        }
    }
        
        
        
        
    }
    
    

